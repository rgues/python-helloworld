import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-country-home',
  templateUrl: './country-home.page.html',
  styleUrls: ['./country-home.page.scss'],
})
export class CountryHomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
