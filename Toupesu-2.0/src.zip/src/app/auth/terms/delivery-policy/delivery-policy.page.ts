import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-policy',
  templateUrl: './delivery-policy.page.html',
  styleUrls: ['./delivery-policy.page.scss'],
})
export class DeliveryPolicyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
