import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-terms-about',
  templateUrl: './terms-about.page.html',
  styleUrls: ['./terms-about.page.scss'],
})
export class TermsAboutPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
