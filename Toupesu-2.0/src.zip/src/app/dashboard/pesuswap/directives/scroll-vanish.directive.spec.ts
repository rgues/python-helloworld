import { ScrollVanishDirective } from './scroll-vanish.directive';

describe('ScrollVanishDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollVanishDirective();
    expect(directive).toBeTruthy();
  });
});
